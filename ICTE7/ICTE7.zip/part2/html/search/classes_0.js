var searchData=
[
  ['complex_0',['Complex',['../struct_complex.html',1,'']]]
];
