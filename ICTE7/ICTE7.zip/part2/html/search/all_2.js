var searchData=
[
  ['magnitude_0',['magnitude',['../complex__operations_8c.html#aa3f43376ef10670923290c2a194a99f3',1,'complex_operations.c']]],
  ['multiply_1',['multiply',['../complex__operations_8c.html#ad9d9f96938ddbd9415f467cfcb34c5da',1,'complex_operations.c']]]
];
