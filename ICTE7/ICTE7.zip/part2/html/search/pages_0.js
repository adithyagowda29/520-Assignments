var searchData=
[
  ['complex_20operations_0',['Complex Operations',['../index.html',1,'']]]
];
