var searchData=
[
  ['subtract_0',['subtract',['../class_calculator.html#ad8a28a8b990342d4bfde65ab85ec7596',1,'Calculator']]]
];
