var searchData=
[
  ['add_0',['add',['../class_calculator.html#a54ca827c4b408c795576d48503eee6aa',1,'Calculator']]]
];
